<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <title>Document</title>
    <style>
        div{
            margin:10px;
            display:flexbox;
        }

        header {
            background-color: #ffffff;
            color: #000000;
            border-style:solid;
            margin-top:5px;
            margin-left:5px;
            margin-right:5px;
            text-align: center;
            box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.8), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: -10px;
        }
        
        button {
            background-color: #333;
            border: none;
            color: #fff;
            cursor: pointer;
            padding: 10px 20px;
        }
        
        input[type="text"]{
            display: block;
        }

        .container{
            border-style:solid;
            margin-top:100px;
            margin-left:500px;
            margin-right:500px;
            box-shadow: 0 4px 10px 0 rgba(0, 0, 0, 0.8), 0 6px 20px 0 rgba(0, 0, 0, 0)
        }


    </style> 
</head>
<body>
    <header>
		<div class="logo">
            <h1>Shoe Stock Management System</h1>
        </div>
	</header>

    <div class="container">
        <div>
            <h1>Update Shoe</h1>
        </div>

        <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
    
        <form action="<?php echo e(url('update',$shoe->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <label>Shoe Name:</label>
                <input type="text" name="name" value="<?php echo e($shoe->name); ?>">
            </div>
    
            <div>
                <label>Size:</label>
                <input type="text" name="size" value="<?php echo e($shoe->size); ?>">
            </div>
    
            <div>
                <label>Color:</label>
                <input type="text" name="color" value="<?php echo e($shoe->color); ?>">
            </div>
    
            <div>
                <label>Quantity:</label>
                <input type="text" name="quantity" value="<?php echo e($shoe->quantity); ?>">
            </div>
            <div>
                <input type="submit" value="Update">
            </div>
            
        </form>
    
        <div>
            <br><br>
                <a href="<?php echo e(url('/home')); ?>">
                    <button type="button" class="btn btn-outline-primary float-right">Home</button>
                </a>
                <a href="<?php echo e(url('/view')); ?>">
                    <button type="button" class="btn btn-outline-primary float-right">List Shoes</button>
                </a>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Codes\PHP\ShoeStockManSys\resources\views/update_page.blade.php ENDPATH**/ ?>