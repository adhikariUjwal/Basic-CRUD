<!DOCTYPE html>
<html>
<head>
	<title>Shoe Stock Management System</title>
	<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
        }
        
        h1 {
            margin: 0;
        }
        
        main {
            padding: 20px;
        }
        
        form label {
            display: block;
            margin-bottom: 10px;
        }
        
        form input {
            display: block;
            margin-bottom: 20px;
            padding: 5px;
            width: 100%;
        }
        
        form button {
            background-color: #333;
            border: none;
            color: #fff;
            cursor: pointer;
            padding: 10px 20px;
        }
        
        table {
            border-collapse: collapse;
            width: 100%;
        }
        
        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        
        table th {
            background-color: #f2f2f2;
        }
        
        table td:last-child {
            text-align: center;
        }
        
        table td button {
            background-color: #333;
            border: none;
            color: #fff;
            cursor: pointer;
            margin-right: 5px;
            padding: 5px 10px;
        }      
    </style>

</head>
<body>
	
	<header>
		<h1>Shoe Stock Management System</h1>
	</header>

	<main>
		<form>
			<label for="shoe-name">Shoe Name:</label>
			<input type="text" id="shoe-name" name="shoe-name" required>
			<label for="shoe-size">Size:</label>
			<input type="number" id="shoe-size" name="shoe-size" required>
			<label for="shoe-color">Color:</label>
			<input type="text" id="shoe-color" name="shoe-color" required>
			<label for="shoe-quantity">Quantity:</label>
			<input type="number" id="shoe-quantity" name="shoe-quantity" required>
			<button type="submit">Add Shoe</button><br><br>
		</form>

        <h1>Stock Details</h1>

		<table>
			<thead>
				<tr>
					<th>Shoe Name</th>
					<th>Size</th>
					<th>Color</th>
					<th>Quantity</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<tr>	
				</tr>

				<tr>
				</tr>
			</tbody>
		</table>

	</main>
</body>
</html><?php /**PATH D:\Codes\PHP\ShoeStockManSys\resources\views/index.blade.php ENDPATH**/ ?>